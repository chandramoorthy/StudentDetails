package com.Students_Details;

public interface  Inter {
	 
	 void display();
	 void insert();
	 void update();
	 void search();
	 void delete();
	 void option();
}

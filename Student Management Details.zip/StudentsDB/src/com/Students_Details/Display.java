package com.Students_Details;

import java.sql.*;

import java.util.*;

import com.mysql.jdbc.PreparedStatement;

public class Display extends abs implements Inter{
	Scanner sc=new Scanner(System.in);
	ArrayList<Student> studentDetails=new ArrayList<Student>();
	Student objarr=new Student();
	int stdID, stdMARK;
	String stdNAME;
	static String connectionUrl = "jdbc:mysql://localhost/studentdb?useSSL=false";
    static String dbUser = "root";
    static String dbPwd = "12345";
    Connection conn = null;
    static ResultSet rs;
    Statement smt = null;
   public void display() {
		try
	    {
	      conn = DriverManager.getConnection(connectionUrl, dbUser, dbPwd);
	      Statement stmt = conn.createStatement();
	      String queryString = "select * from student";
	      rs = stmt.executeQuery(queryString);
	      System.out.println("ID \tNAME  \t\tMARK");
		    System.out.println("----------------------------");
		    while(rs.next())
		    {
		      System.out.print(rs.getInt("ID") + ".\t" + rs.getString("NAME")+"  \t\t"+rs.getInt("MARK"));
		      System.out.println();
		    }
		  
	      if (conn != null)
	      {
	        conn.close();
	        conn = null;
	      }
	      System.out.println("Do you want to Continue.?");
	      option();
	    }
	    catch (SQLException sqle) 
	    {
	      System.out.println("SQL Exception thrown: " + sqle);
	    }
	}
	public void insert() {
		
			System.out.println("Enter ID");
			 stdID=sc.nextInt();
			 System.out.println("Enter Name");
			 stdNAME=sc.next();
			 System.out.println("Enter Mark");
			 stdMARK=sc.nextInt();
			 try {
		  			if(stdMARK>101) {
		  				manageexception("Mark");
					    }
		  		}
		  		catch(Exception e)
		  				{
		  			System.out.println(e);
		  			System.out.println("\nMark Range Should be <=100 Please Re-enter the Details\n");
		  			option();
		  		}
			objarr=new Student(stdID, stdNAME, stdMARK);  
			studentDetails.add(objarr);
			System.out.println("Do you want to enter another record.?\n1.YES\t\t2.NO (or) SAVE\t\t3.Cancel");
			  	int newrec=sc.nextInt();
			  if(newrec==1) {
			  	insert();
			  	}
			  else if(newrec==2) {
			  		Iterator<Student> itr=studentDetails.iterator();
					while(itr.hasNext())
					{
						Student ty=(Student)itr.next();
						try
						{
						Class.forName("com.mysql.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost/studentdb", "root", "12345");
						 String sql = "insert into student (id,name,mark) values (?,?,?)";
						PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
						ps.setInt(1,ty.getStdID());
					      ps.setString(2, ty.getStdNAME());
					      ps.setInt(3, ty.getStdMARK());
					      ps.execute();
					    
						}
						catch(Exception e)
						{
							
							
						}
						  
					}
					option();
			  	}else if(newrec==3) {
			  		System.exit(0);
			  	}
	    
			  			}
	void manageexception(String MARK) throws InvalidException {
		if (MARK=="Mark") {
	            throw new InvalidException("Invalid Mark Input");
				}else {
			System.out.println("Exception Catched: ");
			}
	}
	public void update() {
		try
	    {
			    System.out.println("Enter Student ID: ");
			    stdID=sc.nextInt();
			    System.out.println("Enter New Name: ");
			    stdNAME=sc.next();
			    System.out.println("Enter New Mark: ");
			    stdMARK=sc.nextInt();
			    if(stdNAME.length()<2){
			    	stringexp(stdNAME);
			    }else {			    
					      conn = DriverManager.getConnection(connectionUrl, dbUser, dbPwd);
					      String updatequery = "update student set name=?, mark=? where id=?";
					      PreparedStatement ps = (PreparedStatement) conn.prepareStatement(updatequery); 
					      ps.setString(1, stdNAME);
					      ps.setInt(2, stdMARK);
					      ps.setInt(3, stdID);
					      
					      ps.executeUpdate();
					      System.out.println("Successfully Updated.!");
					      option();
					      ps.close();
					      if (conn != null)
					      {
					        conn.close();
					        conn = null;
					      }
					 }
			    }
	    catch (Exception e) 
	    {
	      System.out.println("SQL Exception: " + e);
	    }	
	}
	public void stringexp(String name){
	    if(name.length()<2){
	    	try {
	    		throw new RuntimeException("String cannot take in an empty String or null value for the Name");
	    	}
	        catch(RuntimeException e) {
	        	System.out.println("String Error:"+e);
	        }
	    }
	}
	public void search() {
		try
	    {
			      System.out.println("Enter Student ID for Search: ");
			      stdID=sc.nextInt();
				  conn = DriverManager.getConnection(connectionUrl, dbUser, dbPwd);
			      String seletquery = "select id, name, mark from student where id='"+stdID+"'";
			      Statement smt=conn.createStatement();
			      rs=smt.executeQuery(seletquery);
			      System.out.println("ID \tNAME  \t\tMARK");
			      System.out.println("----------------------------");
			      while(rs.next()) {
			      System.out.println(rs.getInt("ID") + ".\t" + rs.getString("NAME")+"  \t\t"+rs.getInt("MARK"));
			      }
			      option();
			      if (conn != null)
			      {
			        conn.close();
			        conn = null;
			      }
	    }
	    catch (Exception e) 
	    {
	      System.out.println("SQL Exception thrown: " + e);
	    }
	}

	public void delete() {
		try
	    {
		  System.out.println("Enter Student ID: ");
		  stdID=sc.nextInt();
	      conn = DriverManager.getConnection(connectionUrl, dbUser, dbPwd);
	      String deletequery = "delete from student where id=?";
	      PreparedStatement ps = (PreparedStatement) conn.prepareStatement(deletequery); 
	      ps.setInt(1, stdID);
	      ps.executeUpdate();
	      System.out.println("Deleted Successfully.!");
	      option();
	      if (conn != null)
	      {
	        conn.close();
	        conn = null;
	      }
	    }
	    catch (Exception e) 
	    {
	      System.out.println("SQL Exception thrown: " + e);
	    }	
	}
	public void option() {
		System.out.println("Choose your Options.\n1.Register\t2.Update\t3.Search\n\n4.Delete\t5.View\t\t6.Exit");
		  int op=sc.nextInt();
		switch(op) {
		  case 1:
			  insert();
			  break;
		  case 2:
			  update();
			  break;
		  case 3:
			  search();
			  break;
		  case 4:
			  delete();
			  break;
		  case 5:
			  display();
			  break;
		  case 6:
			  System.exit(0);
			  break;
			  default:
				  System.out.println("Please Choose Correct Option.");
				  break;
		  }
	}

}

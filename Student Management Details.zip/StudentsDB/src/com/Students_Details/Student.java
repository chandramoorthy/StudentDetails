package com.Students_Details;

public class Student {
		private int stdID;  
	    private   String stdNAME;  
	    private  int stdMARK; 
	    
	
	Student(int stdID,String stdNAME,int stdMARK){  
		   this.stdID=stdID;  
		   this.stdNAME=stdNAME;  
		   this.stdMARK=stdMARK;  
	  }  
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public int getStdID() {
		return stdID;
	}
	public void setStdID(int stdID) {
		this.stdID = stdID;
	}
	public String getStdNAME() {
		return stdNAME;
	}
	public void setStdNAME(String stdNAME) {
		this.stdNAME = stdNAME;
	}
	public int getStdMARK() {
		return stdMARK;
	}
	public void setStdMARK(int stdMARK) {
		this.stdMARK = stdMARK;
	}
}

package com.Students_Details;

public class InvalidException extends Exception {

	public InvalidException(String string) {
		//System.out.println("Exception Class");
	}
	

}

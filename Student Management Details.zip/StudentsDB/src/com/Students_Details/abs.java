package com.Students_Details;

abstract class abs implements Inter{
	public abstract void search();
		
	}



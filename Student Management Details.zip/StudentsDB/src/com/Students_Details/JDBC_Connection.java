package com.Students_Details;

import java.util.Scanner;

public class JDBC_Connection extends Display{ 
  public static void main(String[] args)
  {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Choose 1 or 2");
	  int ab=sc.nextInt();
	  if(ab==1) {
		  JDBC_Connection obj1=new JDBC_Connection();
		  obj1.option(); 
	  }
	  else if(ab==2) {
		  Inter interobj= new Display();
		  interobj.search();
	  }else {
		  System.out.println("Choose correct");
	  }
	 sc.close();
  }
}
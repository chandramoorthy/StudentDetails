package com.Students_Details;

abstract class abs {
	abstract void search();

	//abstract void option();
}


package com.Students_Details;

public class JDBC_Connection extends Display
{
  public static void main(String[] args)
  {
	  JDBC_Connection obj1=new JDBC_Connection();
	  obj1.option();
	    //abs ab= new Display();
	    /*ab.search();*/
	    
  }
}
package com.Students_Details;

public class InvalidException extends Exception {

	public InvalidException(String string) {
		// TODO Auto-generated constructor stub
	}
	

}
